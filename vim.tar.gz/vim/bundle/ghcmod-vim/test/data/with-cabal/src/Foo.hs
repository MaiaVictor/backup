module Foo where
import Foo.Bar

foo = bar ++ ""
