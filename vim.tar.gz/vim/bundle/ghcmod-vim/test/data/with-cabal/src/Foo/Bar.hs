module Foo.Bar (bar) where

bar = x
  where
    x = id $ "bar"
