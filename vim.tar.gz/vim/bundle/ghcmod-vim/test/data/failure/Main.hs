module Main where

compileError = "foo" + 0

main = return ()
