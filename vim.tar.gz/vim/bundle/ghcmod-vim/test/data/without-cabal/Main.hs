module Main where
import Foo.Bar

main = return ()
