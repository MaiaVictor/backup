{-| This is a long module level haddock

  Example:

  > module FakeModule where
  >
  > fake = fake

  > module AnotherFakeModule where
  >
  > fake = fake

  > module YetAnotherFakeModule where
  >
  > fake = fake
-}

module ActualModule where

actual = actual
