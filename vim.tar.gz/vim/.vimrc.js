(function(){
	set;
	return e;
})()
